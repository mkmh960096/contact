@extends('admindash')
@section('content')

<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <p>
            <a href="{{url('/addcontact')}}" class="btn btn-danger">add contact</a>
            <a href="{{url('/allcontact')}}" class="btn btn-danger">all contact</a>


          </p>

        <form action={{URL::to('savecontact')}} method="post" >
          @csrf

          

          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>name</label>
              <input type="text" class="form-control" placeholder=" name" name="name"  >
            </div>
            <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>subject</label>
              <input type="text" class="form-control" placeholder="subject" name="slug" required >

              <div class="form-group">
            <button type="submit" class="btn btn-primary">submit</button>
          </div>
            </div>
          </div>
          
        
        
  
@endsection