 @extends('admindash')
@section('content')



             <a href="{{route('add.catagory')}}" class="btn btn-danger">add catagory</a>
            <a href="{{route('all.catagory')}}" class="btn btn-danger">all catagory</a>


<div>
	<<ol>
		<li>catagory name:{{$catagory->name}}</li>
		<li>catagory slug:{{$catagory->slug}}</li>



	</ol>
</div>
@endsection