@extends('admindash')
@section('content')
<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <p>
            <a href="{{route('add.catagory')}}" class="btn btn-danger">add catagory</a>
            <a href="{{route('all.catagory')}}" class="btn btn-danger">all catagory</a>


          </p>

        <form action={{url('update/catagory/'.$catagory->id)}} method="post">
          @csrf

          

          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>catagory name</label>
              <input type="text" class="form-control" value="{{$catagory->name}}" name="name" required >
            </div>
          </div>
          <br>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>slug name</label>
              <textarea rows="5" class="form-control" value="{{$catagory->slug}}" name="slug" required ></textarea>
            </div>
          </div>

          <div class="form-group">
            <button type="submit" class="btn btn-primary">update</button>
          </div>
      </br>
          
  
@endsection