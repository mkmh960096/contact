@extends('admindash')
@section('content')

  <!-- Page Header -->
  
        
                            <a href="{{url('/addcontact')}}" class="btn btn-danger">add contact</a>
                            <a href="{{url('/allcontact')}}" class="btn btn-danger">all contact</a>


                     <table class="table">
							  
								  <tr>
									  <th> id</th>
									  <th>name </th>
									  <th>subject</th>
									                                            
								  </tr>
							  
								@foreach($contact as $row)
								<tr>
									<td>{{$row->id}}</td>
									<td >{{$row->name}}</td>
									<td >{{$row->slug}}</td>
									
                              
                               <td>

			              <a href="{{URL::to ('/view/contact/'.$row->id)}}" class=" btn btn-info">view</a>
			              <a href="{{URL::to ('/view/contact/'.$row->id)}}" class=" btn btn-info">edit</a>
			              <a href="{{URL::to ('/view/contact/'.$row->id)}}" class=" btn btn-info">delete</a>
			              
			              
                             </td>                                       
								</tr>
								                                  
							  @endforeach
							  
						 </table> 


          
  
@endsection