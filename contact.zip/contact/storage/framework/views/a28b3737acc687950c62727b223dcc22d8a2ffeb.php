<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <p>
            <a href="<?php echo e(url('/addcontact')); ?>" class="btn btn-danger">add contact</a>
            <a href="<?php echo e(url('/allcontact')); ?>" class="btn btn-danger">all contact</a>


          </p>

        <form action=<?php echo e(URL::to('savecontact')); ?> method="post" >
          <?php echo csrf_field(); ?>

          

          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>name</label>
              <input type="text" class="form-control" placeholder=" name" name="name"  >
            </div>
            <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>subject</label>
              <input type="text" class="form-control" placeholder="subject" name="slug" required >

              <div class="form-group">
            <button type="submit" class="btn btn-primary">submit</button>
          </div>
            </div>
          </div>
          
        
        
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admindash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\contact\resources\views/addcontact.blade.php ENDPATH**/ ?>