<?php $__env->startSection('content'); ?>

  <!-- Page Header -->
  
        
                            <a href="<?php echo e(url('/addcontact')); ?>" class="btn btn-danger">add contact</a>
                            <a href="<?php echo e(url('/allcontact')); ?>" class="btn btn-danger">all contact</a>


                     <table class="table">
							  
								  <tr>
									  <th> id</th>
									  <th>name </th>
									  <th>subject</th>
									                                            
								  </tr>
							  
								<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($row->id); ?></td>
									<td ><?php echo e($row->name); ?></td>
									<td ><?php echo e($row->slug); ?></td>
									
                              
                               <td>

			              <a href="<?php echo e(URL::to ('/view/contact/'.$row->id)); ?>" class=" btn btn-info">view</a>
			              <a href="<?php echo e(URL::to ('/view/contact/'.$row->id)); ?>" class=" btn btn-info">edit</a>
			              <a href="<?php echo e(URL::to ('/view/contact/'.$row->id)); ?>" class=" btn btn-info">delete</a>
			              
			              
                             </td>                                       
								</tr>
								                                  
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							  
						 </table> 


          
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admindash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\contact\resources\views/allcontact.blade.php ENDPATH**/ ?>