<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class addcontroller extends Controller
{
    public function addcontact()
  {
     return view('addcontact');

  }


  public function savecontact(Request $request)
  {
       $data=array();
        $data['name']=$request->name;
        $data['slug']=$request->slug;

        $contact=DB::table('contact')->insert($data);
         return view('addcontact', compact('contact'));

 //return Redirect::to('/addcontact');
         }



   public function updatecontact(Request $request ,$id)
    {
          $data=array();
        $data['name']=$request->name;
        $data['slug']=$request->slug;

        $contact=DB::table('contact')->update($data);
    }


public function allcontact()
    {
        $contact=DB::table('contact')->get();
        return view('allcontact',compact('contact'));

    }

    public function viewcontact($id)
    {
        $contact=DB::table('contact')->where('id','$id')->frist();
        return view('viewcontact',compact('contact'));

    }

    public function editcontact($id)
    {
        $contact=DB::table('contact')->where('id','$id')->frist();
        return view('editcontact',compact('contact'));
    }

public function deletecontact($id)
    {
        $delete=DB::table('contact')->where('id','$id')->delete();
        return view('delete_catagory',compact('delete'));
    }

}
