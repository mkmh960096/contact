<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/admindash','admincontroller@admindash');
Route::get('/dashboard','admincontroller@dashboard');
Route::get('/addcontact','addcontroller@addcontact');
Route::post('/savecontact','addcontroller@savecontact');
Route::get('/allcontact','addcontroller@allcontact');
Route::get('/view/contact/{id}','addcontroller@viewcontact');
Route::get('/edit/contact/{id}','addcontroller@editcontact');
Route::get('/delete/contact/{id}','addcontroller@deletecontact');



/*Route::get('/addcontact','addcontact_controller@addcontact');
Route::get('/savecontact','addcontact_controller@savecontact');
Route::get('/allcontact','allcontact_controller@allcontact');

Route::get('/view/contact/{id}','addcontact_controller@viewcontact');
Route::get('/edit/contact/{id}','addcontact_controller@editcontact');
Route::get('/delete/contact/{id}','addcontact_controller@deletecontact');
Route::get('/update/contact/{id}','addcontact_controller@updatecontact');
*/